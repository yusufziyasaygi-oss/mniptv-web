#!/bin/bash
# MN Player: compare Quick Look routing on one known-good synthetic MXF.
# No sudo, preference changes, uploads or access to personal videos.
set -o pipefail
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
tmp=$(mktemp -d "${TMPDIR:-/tmp}/MN-MXF.XXXXXX") || exit 1
trap 'rm -rf "$tmp"' EXIT
cd "$tmp" || exit 1
/usr/bin/sw_vers
ext='/Applications/MN Player.app/Contents/PlugIns/MXFFirstFrame.appex'
echo "MN Player uzantı kaydı"
/usr/bin/pluginkit -mAvv -i com.mavinokta.player.mxf-thumbnail
/usr/bin/codesign --verify --strict "$ext" && echo "Uzantı imza bütünlüğü: OK"
start=$(/bin/date '+%Y-%m-%d %H:%M:%S')
for kind in otomatik org.smpte.mxf org.videolan.mxf; do
    mkdir "$kind"
    /bin/cp "$base/MN-kontrol.MXF" "$kind.MXF" || exit 1
    args=()
    if [ "$kind" != otomatik ]; then args=(-c "$kind"); fi
    echo "Küçük resim isteği: $kind"
    /usr/bin/qlmanage -x -t -s 160 "${args[@]}" -o "$kind" "$PWD/$kind.MXF" > "$kind/output" 2>&1 &
    pid=$!
    # An interactive Quick Look request must not leave the report waiting indefinitely.
    ( sleep 15; kill "$pid" 2>/dev/null ) & watchdog=$!
    wait "$pid"
    kill "$watchdog" 2>/dev/null || true
    wait "$watchdog" 2>/dev/null || true
    for image in "$kind"/*.png; do
        if [ -f "$image" ]; then /usr/bin/sips -g pixelWidth -g pixelHeight "$image" | tail -2
        else echo "PNG üretilmedi"; /usr/bin/tail -3 "$kind/output"; fi
    done
done
echo "Quick Look tanı kayıtları"
/usr/bin/log show --start "$start" --info --style compact --predicate '(process == "MXFFirstFrame" OR eventMessage CONTAINS[c] "MXFFirstFrame" OR eventMessage CONTAINS[c] "com.mavinokta.player.mxf-thumbnail" OR subsystem BEGINSWITH[c] "com.apple.quicklook" OR process CONTAINS[c] "ThumbnailsAgent") AND (messageType == error OR messageType == fault OR eventMessage CONTAINS[c] "generator" OR eventMessage CONTAINS[c] "provider" OR eventMessage CONTAINS[c] "denied" OR eventMessage CONTAINS[c] "failed" OR eventMessage CONTAINS[c] "org.smpte.mxf")' | tail -35
echo "Kontrol tamamlandı."
